# burp-authentication-mapper

A [Claude Code](https://claude.ai/code) skill that maps authentication flows from Burp Suite HTTP History. Invoke it during or after a proxied session to automatically document how a web application handles authentication — without manually reading through raw requests.

## What It Does

Fetches auth-related traffic from the Burp Suite proxy, classifies each request into a flow step, and produces:

- **ASCII sequence diagram** — Browser ↔ Server interaction with credential masking; static assets (`.gif`, `.jpg`, `.png`, `.ico`, `.css`, `.woff`, `.woff2`, `.ttf`, `.svg`) are excluded; on PortSwigger Web Security Academy labs (`web-security-academy.net`), `GET /academyLabHeader` WebSocket upgrade requests are also excluded
- **Session identifier table** — lifecycle state (pre-auth / authenticated / post-logout), request counts, and context for each unique session cookie
- **CSRF / anti-forgery token table** — where tokens are issued and where they are submitted

Works with any web application: form-based login, JWT/OAuth2 token flows, MFA challenges, SSO callbacks, and more.

---

## Installation & Usage

### Claude Code

Copy the skill directory into your Claude Code skills folder:

```bash
cp -r burp-authentication-mapper ~/.claude/skills/
```

Ensure the Burp Suite MCP server is running and connected, then invoke in a Claude Code session:

```
/burp-authentication-mapper
```

Claude will prompt you to select a time window, then fetch, parse, and report on the authentication flow captured in that window.

---

### Google Gemini CLI

The `SKILL.md` format used by this skill is compatible with Gemini CLI's native Agent Skills system. There are two ways to use it.

#### Option A — gemini-cli-skillz (recommended)

[gemini-cli-skillz](https://github.com/intellectronica/gemini-cli-skillz) is a Gemini CLI extension that loads Anthropic-style `SKILL.md` skills directly. It lets you share the same skills directory between Claude Code and Gemini CLI without duplicating files.

**1. Install the extension:**

```bash
gemini extensions install https://github.com/intellectronica/gemini-cli-skillz
```

**2. Symlink your Claude Code skills directory:**

```bash
ln -s ~/.claude/skills ~/.skillz
```

Or if you cloned this repo standalone, point it at the skill directory:

```bash
mkdir -p ~/.skillz
cp -r burp-authentication-mapper ~/.skillz/
```

**3. Restart Gemini CLI.** The skill is loaded automatically. Describe what you want in natural language and Gemini will activate it:

```
Map the authentication flow I just captured in Burp
```

#### Option B — Native Gemini CLI Skills

Gemini CLI also has a built-in Agent Skills system that reads `SKILL.md` files from `~/.gemini/skills/`. The frontmatter format is identical.

**1. Copy the skill into the Gemini skills directory:**

```bash
mkdir -p ~/.gemini/skills
cp -r burp-authentication-mapper ~/.gemini/skills/
```

**2. Invoke via natural language** in a Gemini CLI session:

```
Map the authentication flow I just captured in Burp
```

Gemini activates the skill automatically when your request matches the skill's description.

#### Option C — Custom Slash Command

For an explicit `/burp-auth-map` slash command in Gemini CLI, create a TOML command file:

```bash
mkdir -p ~/.gemini/commands
```

Create `~/.gemini/commands/burp-auth-map.toml`:

```toml
description = "Map authentication flows from Burp Suite HTTP History"
prompt = """
Follow the workflow defined in the burp-authentication-mapper skill.
Prompt the user to select a time window (Last 5 minutes, Last 15 minutes,
Last 30 minutes, or Last 1 hour), then fetch auth-related Burp proxy history,
classify the requests, and produce an ASCII sequence diagram, session
identifier table, and CSRF token table.
"""
```

Then reload commands without restarting:

```
/commands reload
```

Invoke with:

```
/burp-auth-map
```

> **Note:** The custom slash command works best when paired with Option A or B so Gemini has access to the full skill instructions, reference files, and parser script.

---

### Time Window Options

| Option | Filter Applied |
|---|---|
| Last 5 minutes | `--minutes 5` |
| Last 15 minutes | `--minutes 15` |
| Last 30 minutes | `--minutes 30` |
| Last 1 hour | `--hours 1` |

---

## Repository Structure

```
burp-authentication-mapper/
├── SKILL.md                          # Skill definition — controls all workflow behavior
├── scripts/
│   └── parse_burp_history.py         # Burp history parser script
└── references/
    ├── auth_patterns.md              # Regex patterns and classification rules
    ├── security_checklist.md         # Security evaluation criteria
    └── example_output.md             # DVWA format reference
```

---

## Artifacts

### `SKILL.md`

The core skill definition. Defines the workflow Claude follows when the skill is invoked:

- **Step 0** — Prompts the user to select a time window using `AskUserQuestion`
- **Step 1** — Fetches auth-related proxy history from Burp via the MCP `get_proxy_http_history_regex` tool using a combined regex covering login, session, CSRF, and credential keywords
- **Step 2** — If results are large (saved to a temp file), runs `parse_burp_history.py` to filter, deduplicate, and classify items; cleans up temp files afterward and reports space freed
- **Step 3** — Generates the final output: sequence diagram, session table, and CSRF token table

### `scripts/parse_burp_history.py`

A deterministic Python 3 parser for Burp MCP tool result files. Run directly — never loaded into Claude's context.

**Capabilities:**
- Reads raw JSON output files from the Burp MCP tool
- Filters items by time window (minutes, hours, or all); items without an HTTP `Date` header (common with HTTP/2) are treated as within the window, timestamped at skill invocation time
- Deduplicates by `method + path + timestamp`
- Classifies each item into an auth flow category (Login Page Load, Credential Submission, Post-Auth Page Load, Static Asset, Logout, etc.)
- Extracts session cookies sent and set, with full security flag details (HttpOnly, Secure, SameSite, Max-Age, Domain, Path)
- Extracts hidden form fields and CSRF tokens from response HTML
- Extracts credential parameters from POST bodies with password masking (`****`)
- Outputs structured JSON to stdout, summary stats to stderr

**Usage:**
```bash
python3 scripts/parse_burp_history.py [--minutes M | --hours H | --all] <file(s)>
```

### `references/auth_patterns.md`

Reference document used for inline processing (when results fit without a temp file). Contains:

- Regex patterns for identifying login endpoints, credential parameters, session tokens, and logout flows
- Item classification rules table (method + path + status → category)
- Data extraction checklist (what to pull from requests and responses)
- Authentication flow type reference: form-based, JWT/OAuth2, MFA, SSO/OIDC authorization code flow, Basic/Digest

### `references/security_checklist.md`

Security evaluation criteria organized by category. Used as a reference when assessing an authentication flow. Covers:

| Category | Example Checks |
|---|---|
| Transport Security | HTTPS, Secure cookie flag, HSTS |
| Session Management | Session rotation on login, HttpOnly, SameSite, expiry, logout invalidation |
| CSRF Protection | Anti-forgery token presence, server-side validation, token rotation |
| Credential Handling | HTTPS transport, no credentials in URL, password field masking |
| Error Handling | Generic vs. specific error messages, stack trace exposure |
| Multi-Factor Auth | MFA present, bypass resistance, one-time token validation |
| Brute Force Protection | Rate limiting, account lockout, CAPTCHA, timing consistency |
| Logout Security | Server-side invalidation, cookie clearing, redirect behavior |

### `references/example_output.md`

A real output sample from mapping a DVWA (Damn Vulnerable Web Application) login flow. Used by Claude as a formatting reference to ensure consistent output structure across runs. Shows the exact layout for:

- The two-column ASCII sequence diagram
- The session identifiers table with lifecycle annotation
- The CSRF token table

---

## Requirements

- [Burp Suite](https://portswigger.net/burp) with the MCP server extension running
- Python 3 (for large-result processing via `parse_burp_history.py`)
- **Claude Code:** [claude.ai/code](https://claude.ai/code) with skills support
- **Gemini CLI:** [Gemini CLI](https://github.com/google-gemini/gemini-cli) with either native skills support or the [gemini-cli-skillz](https://github.com/intellectronica/gemini-cli-skillz) extension

---

## Example Output

```
Target: DVWA @ 127.0.0.1:4280
Time window: 13:39 - 13:44 UTC (Feb 16, 2026)
Authentication type: Form-based authentication with CSRF protection

## ASCII Sequence Diagram

Browser                                        DVWA Server
  |                                                 |
  |  1. GET /logout.php                             |
  |------------------------------------------------>|
  |  302 Found -> login.php                         |
  |  Set-Cookie: PHPSESSID=95ce75...                |
  |<------------------------------------------------|
  |                                                 |
  |  2. GET /login.php                              |
  |    Cookie: PHPSESSID=95ce75...                  |
  |------------------------------------------------>|
  |  200 OK                                         |
  |  Hidden: user_token=f970eb7f...                 |
  |<------------------------------------------------|
  |                                                 |
  |  3. POST /login.php                             |
  |    username=admin                               |
  |    password=****                                |
  |    user_token=f970eb7f...                       |
  |    Cookie: PHPSESSID=95ce75...                  |
  |------------------------------------------------>|
  |  302 Found -> index.php                         |
  |  Set-Cookie: PHPSESSID=ff91cf... (rotated)      |
  |<------------------------------------------------|
```

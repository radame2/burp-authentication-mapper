# Example Output — DVWA Authentication Mapping

This is a real output from mapping the DVWA (Damn Vulnerable Web Application) authentication flow.
Use this as a format reference to ensure consistent output structure.

---

**Target:** DVWA @ `127.0.0.1:4280`
**Scope:** Last 25 requests (2026-02-16)
**Authentication type:** Form-based authentication with CSRF protection

---

## ASCII Sequence Diagram

```
Browser                                        DVWA Server
  |                                                 |
  |  1. GET /logout.php                             |
  |------------------------------------------------>|
  |  302 Found -> login.php                         |
  |  Set-Cookie: PHPSESSID=95ce75...                |
  |<------------------------------------------------|
  |                                                 |
  |  2. GET /login.php                              |
  |    Cookie: PHPSESSID=95ce75...                  |
  |------------------------------------------------>|
  |  200 OK                                         |
  |  Hidden: user_token=f970eb7f...                 |
  |<------------------------------------------------|
  |                                                 |
  |  3-4. GET /dvwa/css, /images  (static assets)   |
  |------------------------------------------------>|
  |<------------------------------------------------|
  |                                                 |
  |  5. POST /login.php                             |
  |    username=admin                               |
  |    password=****                                |
  |    user_token=f970eb7f...                       |
  |    Cookie: PHPSESSID=95ce75...                  |
  |------------------------------------------------>|
  |  302 Found -> index.php                         |
  |  Set-Cookie: PHPSESSID=ff91cf...                |
  |  (session rotated on login)                     |
  |<------------------------------------------------|
  |                                                 |
  |  6. GET /index.php                              |
  |    Cookie: PHPSESSID=ff91cf...                  |
  |------------------------------------------------>|
  |  200 OK — Authenticated DVWA dashboard          |
  |<------------------------------------------------|
  |                                                 |
  |  7-8. GET /images, /js  (static assets)         |
  |------------------------------------------------>|
  |<------------------------------------------------|
  |                                                 |
```

## Session Identifiers

| # | PHPSESSID | State | Set On | Requests |
|---|---|---|---|---|
| 1 | `95ce754a2f847d048fd4af2a2fa51211` | Pre-auth | `/logout.php` | 4 |
| 2 | `ff91cf8b6f2491789cbdae695eed55e9` | Authenticated | `/login.php` | 3 |

**Cookie flags:** `Secure` ✓ · `HttpOnly` ✓ · `SameSite=Lax` ✓

## CSRF / Anti-Forgery Tokens

| Token Name | Value | Found In | Submitted In |
|---|---|---|---|
| `user_token` | `f970eb7fb77d44d785014b94d6c980f1` | `GET /login.php` (hidden field) | `POST /login.php` (form body) |

